from __future__ import annotations

import json
from decimal import Decimal
from typing import Any

import boto3

from config import AWS_REGION, ALERTS_TABLE, AREA_SUMMARIES_TABLE


dynamodb = boto3.resource("dynamodb", region_name=AWS_REGION)
alerts_table = dynamodb.Table(ALERTS_TABLE)
area_summaries_table = dynamodb.Table(AREA_SUMMARIES_TABLE)


def _to_dynamodb_compatible(value: Any) -> Any:
    if isinstance(value, float):
        return Decimal(str(value))
    if isinstance(value, dict):
        return {k: _to_dynamodb_compatible(v) for k, v in value.items()}
    if isinstance(value, list):
        return [_to_dynamodb_compatible(v) for v in value]
    return value


def store_alert(data: dict[str, Any]) -> None:
    item = _to_dynamodb_compatible(data)
    alerts_table.put_item(Item=item)
    print(
        f"Stored ALERT | area={data.get('area_id')} "
        f"pole={data.get('pole_id')} "
        f"alert_type={data.get('alert_type')}"
    )


def store_area_summary(data: dict[str, Any]) -> None:
    item = _to_dynamodb_compatible(data)
    area_summaries_table.put_item(Item=item)
    print(
        f"Stored AREA_SUMMARY | area={data.get('area_id')} "
        f"classification={data.get('classification')}"
    )


def lambda_handler(event: dict[str, Any], context: Any) -> dict[str, Any]:
    processed_count = 0
    failed_count = 0

    for record in event.get("Records", []):
        try:
            body = json.loads(record["body"])
            message_type = body["type"]
            data = body["data"]

            if message_type == "ALERT":
                store_alert(data)
            elif message_type == "AREA_SUMMARY":
                store_area_summary(data)
            else:
                print(f"Unknown message type: {message_type}")
                failed_count += 1
                continue

            processed_count += 1

        except Exception as exc:
            print(f"Error processing record: {exc}")
            failed_count += 1

    return {
        "statusCode": 200,
        "processed_count": processed_count,
        "failed_count": failed_count,
    }